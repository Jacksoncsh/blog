<?php /*a:1:{s:70:"C:\wamp64\www\blog\tp5\application\frontend\view\index\content_md.html";i:1534421461;}*/ ?>
<!DOCTYPE html>
<!-- saved from url=(0032)http://fapiao.itdiffer.com/login -->
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <title> 内容页 </title>
  <!-- Bootstrap Core CSS -->
  <link href="./static/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome CSS -->
  <link href="./static/libs/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Custom CSS -->
  <link href="./static/css/blog.css" rel="stylesheet">
  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
      <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./index.html">我的博客</a>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav">
          <li><a href="./index.html">首页</a></li>
          <li><a href="./list.html">文章列表</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href="./login.html">登录</a></li>
          <li><a href="./registration.html">注册</a></li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">我 <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="./backstage_management.html"><i class="fa fa-dashboard fa-fw"></i> 管理后台</a></li>
              <li><a href="#"><i class="fa fa-sign-out fa-fw"></i> 安全退出</a></li>
            </ul>
          </li>
        </ul>
      </div>
      <!--/.nav-collapse -->
    </div>
  </nav>
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class="visible-md visible-lg">
          <div class="panel panel-custom">
            <div class="panel-heading">相关文章</div>
            <div class="list-group list-group-flush">
              <a href="./content.html" class="list-group-item">如何防止服务器攻击</a>
              <a href="./content.html" class="list-group-item">如何防止服务器攻击</a>
              <a href="./content.html" class="list-group-item">如何防止服务器攻击</a>
              <a href="./content.html" class="list-group-item">如何防止服务器攻击</a>
              <a href="./content.html" class="list-group-item">如何防止服务器攻击</a>
            </div>
          </div>
        </div>
        <div class="visible-md visible-lg">
          <div class="panel panel-custom">
            <div class="panel-heading">博客分类</div>
            <div class="list-group list-group-flush">
              <a href="./list.html" class="list-group-item">生活随想<span class="badge">10</span></a>
              <a href="./list.html" class="list-group-item">心灵鸡汤<span class="badge">3</span></a>
              <a href="./list.html" class="list-group-item">php语言<span class="badge">13</span></a>
              <a href="./list.html" class="list-group-item">mysql数据库<span class="badge">2</span></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-9">
        <ol class="breadcrumb">
          <li><a href="./index.html">首页</a></li>
          <li><a href="content_md.html">Spring 管理</a></li>
          <li class="active">文章</li>
        </ol>
        <section class="content-wrap">
          <header class="post-head">
            <h1 class="post-title">如何防止服务器攻击</h1>
            <span class="author">作者：<a href="./users.html"> 超级无敌大飞</a></span> •
            <time class="post-date" datetime="2016-12-27 12:35:14.0" title="2016-12-27 12:35:14.0">2016年12月27日 星期二</time>
            &nbsp;&nbsp;&nbsp;阅读 (6985)
          </header>
          <hr>
          <section class="post-content">
            <div id='editormd-view'>
              <textarea style="display:none;">### 主要特性

- 支持“标准”Markdown / CommonMark和Github风格的语法，也可变身为代码编辑器；
- 支持实时预览、图片（跨域）上传、预格式文本/代码/表格插入、代码折叠、搜索替换、只读模式、自定义样式主题和多语言语法高亮等功能；
- 支持ToC（Table of Contents）、Emoji表情、Task lists、@链接等Markdown扩展语法；
- 支持TeX科学公式（基于KaTeX）、流程图 Flowchart 和 时序图 Sequence Diagram;
- 支持识别和解析HTML标签，并且支持自定义过滤标签解析，具有可靠的安全性和几乎无限的扩展性；
- 支持 AMD / CMD 模块化加载（支持 Require.js & Sea.js），并且支持自定义扩展插件；
- 兼容主流的浏览器（IE8+）和Zepto.js，且支持iPad等平板设备；
- 支持自定义主题样式；

# Editor.md

![](https://pandao.github.io/editor.md/images/logos/editormd-logo-180x180.png)
</textarea> 
            </div>
          </section>
          <hr>
          <section class="post-content">
            <div class="blog-copyright">
              <span title="CDCN - 码上中国博客文章版权属于作者，受法律保护。未经作者同意不得转载。">©
                著作权归作者所有</span>
            </div>
          </section>
          <section class="post-content">
            <b>分类</b>&nbsp;&nbsp;&nbsp;
            <a href="./list.html"><span class="badge blue">Spring 管理</span></a>
          </section>
          <br>
          <section class="post-content"> 
            <b>标签</b>&nbsp;&nbsp;&nbsp;
            <a href="./tag_list.html"><span class="badge blue">linux 中文乱码</span></a>&nbsp;&nbsp;
            <a href="./tag_list.html"><span class="badge blue">centos 中文乱码</span></a>&nbsp;&nbsp;
            <a href="./tag_list.html"><span class="badge blue">centos设置中文界面</span></a>&nbsp;&nbsp;
          </section>
        </section>
      </div>
    </div>
  </div>
  <script></script>
  <!-- jQuery -->
  <script src="./js/jquery.min.js"></script>
  <!-- Bootstrap Core JavaScript -->
  <script src="./libs/bootstrap/js/bootstrap.min.js"></script>

  <script src="./libs/editormd/lib/marked.min.js"></script>
  <script src="./libs/editormd/lib/prettify.min.js"></script>
  <script src="./libs/editormd/lib/raphael.min.js"></script>
  <script src="./libs/editormd/lib/underscore.min.js"></script>
  <script src="./libs/editormd/lib/sequence-diagram.min.js"></script>
  <script src="./libs/editormd/lib/flowchart.min.js"></script>
  <script src="./libs/editormd/lib/jquery.flowchart.min.js"></script>
  <script src="./libs/editormd/editormd.min.js"></script>
  <script>
    $(function(){
        editormd.markdownToHTML("editormd-view", {
          htmlDecode      : "style,script,iframe",  // you can filter tags decode
          emoji           : true,
          taskList        : true,
          tex             : true,  // 默认不解析
          flowChart       : true,  // 默认不解析
          sequenceDiagram : true,  // 默认不解析
        });
    });
  </script>

</body>

</html>