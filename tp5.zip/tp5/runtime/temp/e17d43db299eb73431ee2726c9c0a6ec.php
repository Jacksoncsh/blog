<?php /*a:1:{s:72:"C:\wamp64\www\blog\tp5\application\frontend\view\index\registration.html";i:1534430911;}*/ ?>
<!DOCTYPE html>
<!-- saved from url=(0032)http://fapiao.itdiffer.com/login -->
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <title> 注册 </title>
  <!-- Bootstrap Core CSS -->
  <link href="./static/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- MetisMenu CSS -->
  <link href="./static/libs/metisMenu/metisMenu.min.css" rel="stylesheet">
  <!-- Font Awesome CSS -->
  <link href="./static/libs/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Custom CSS -->
  <link href="./static/css/sb-admin-2.min.css" rel="stylesheet">
  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
      <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body style="">
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-md-offset-4">
        <div class="login-panel panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title">注册</h3>
          </div>
          <div class="panel-body">
            <form role="form" class="login-form" action="" novalidate="novalidate">
              <fieldset>
                <div class="form-group">
                  <input class="form-control" placeholder="用户名" name="username" autofocus="" autocomplete="off">
                </div>
                <div class="form-group">
                  <input class="form-control" placeholder="密码" name="password" type="password" value="">
                </div>
                <div class="form-group">
                  <input class="form-control" placeholder="重复密码" name="password" type="password" value="">
                </div>
                <!-- Change this to a button or input when using this as a form -->
                <div class="form-group">
                  <button class="btn btn-lg btn-success btn-block">注册</button>
                </div>
                <a class="text-warning" href="./login.html">已有账号-登录</a>
                <a class="text-warning" href="./index.html" style="float: right;">返回首页</a>
              </fieldset>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id="modal" class="modal"></div>
  <script></script>
  <!-- jQuery -->
  <script src="./static/js/jquery.min.js"></script>
  <!-- Bootstrap Core JavaScript -->
  <script src="./static/libs/bootstrap/js/bootstrap.min.js"></script>
  <!-- Metis Menu Plugin JavaScript -->
  <script src="./static/libs/metisMenu/metisMenu.min.js"></script>
  <!-- Custom Theme JavaScript -->
  <script src="./static/js/sb-admin-2.js"></script>
</body>

</html>