<?php /*a:1:{s:68:"C:\wamp64\www\blog\tp5\application\frontend\view\index\tag_list.html";i:1534418509;}*/ ?>
<!DOCTYPE html>
<!-- saved from url=(0032)http://fapiao.itdiffer.com/login -->
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <title> 标签列表 </title>
  <!-- Bootstrap Core CSS -->
  <link href="./static/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome CSS -->
  <link href="./static/libs/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Custom CSS -->
  <link href="./static/css/blog.css" rel="stylesheet">
  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
      <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./index.html">我的博客</a>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav">
          <li><a href="./index.html">首页</a></li>
          <li><a href="./list.html">文章列表</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href="./login.html">登录</a></li>
          <li><a href="./registration.html">注册</a></li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">我 <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="./backstage_management.html"><i class="fa fa-dashboard fa-fw"></i> 管理后台</a></li>
              <li><a href="#"><i class="fa fa-sign-out fa-fw"></i> 安全退出</a></li>
            </ul>
          </li>
        </ul>
      </div>
      <!--/.nav-collapse -->
    </div>
  </nav>
  <!-- navbar -->
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class="visible-md visible-lg">
          <div class="panel panel-custom">
            <div class="panel-heading">热门标签</div>
            <div class="content tag-cloud">
              <a href="./list.html">jquery</a>
              <a href="./list.html">mysql</a>
              <a href="./list.html">服务器</a>
              <a href="./list.html">php</a>
              <a href="./list.html">网站安全</a>
              <a href="./list.html">网站安全</a>
              <a href="./list.html">网站安全</a>
              <a href="./list.html">网站安全</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-9">
        <ol class="breadcrumb">
          <li><a href="#">首页</a></li>
          <li class="active">热门标签</li>
        </ol>
        <div class="post-list list-group">
          <div class="list-group-item">
            <h4 class="list-group-item-heading">
              <a href="./content.html">最新国外六大免费PHP虚拟主机</a>
            </h4>
            <p>
              <span class="label label-info"><b>2018年07月09日  11点23分</b></span>
              &nbsp;&nbsp;&nbsp;阅读 <span class="badge">2853</span>
            </p>
            <p class="subtitle">
              小编除了上一篇分享的国外虚拟主机/免费空间以外，又整理了一个国外的PHP免费主机，来给大家分享下。
            </p>
          </div>
          <hr>
          <div class="list-group-item">
            <h4 class="list-group-item-heading">
              <a href="./content.html">最新国外六大免费PHP虚拟主机</a>
            </h4>
            <p>
              <span class="label label-info"><b>2018年07月09日  11点23分</b></span>
              &nbsp;&nbsp;&nbsp;阅读 <span class="badge">2853</span>
              <!-- &nbsp;&nbsp;&nbsp;<a class="author" href="./用户页.html">超级无敌大飞</a> -->
            </p>
            <p class="subtitle">
              小编除了上一篇分享的国外虚拟主机/免费空间以外，又整理了一个国外的PHP免费主机，来给大家分享下。
            </p>
          </div>
          <hr>
          <div class="list-group-item">
            <h4 class="list-group-item-heading">
              <a href="./content.html">最新国外六大免费PHP虚拟主机</a>
            </h4>
            <p>
              <span class="label label-info"><b>2018年07月09日  11点23分</b></span>
              &nbsp;&nbsp;&nbsp;阅读 <span class="badge">2853</span>
            </p>
            <p class="subtitle">
              小编除了上一篇分享的国外虚拟主机/免费空间以外，又整理了一个国外的PHP免费主机，来给大家分享下。
            </p>
          </div>
          <hr>
        </div>
        <ul class="pagination">
          <li class="active"><a href="#">1</a></li>
          <li><a href="#">2</a></li>
          <li><a href="#">3</a></li>
          <li><a href="#" aria-label="Next">下一页</a></li>
          <li><a href="#" aria-label="Last">尾页</a></li>
        </ul>
      </div>
    </div>
  </div>
  <script></script>
  <!-- jQuery -->
  <script src="./static/js/jquery.min.js"></script>
  <!-- Bootstrap Core JavaScript -->
  <script src="./static/libs/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>